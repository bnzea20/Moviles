package com.interfaces.pokedex.pokeAPI.modelos;

public class Ability {
    private String name;
    private String url;

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }
}
