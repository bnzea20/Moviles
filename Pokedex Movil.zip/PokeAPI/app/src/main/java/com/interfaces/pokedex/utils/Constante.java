package com.interfaces.pokedex.utils;

public class Constante {
    public final static String DEBUG_POKEMON = "DEBUG_POKEMON";
    public final static String EXTRA_POKEMON_ID = "EXTRA_POKEMON_ID";
}
