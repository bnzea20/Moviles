package com.interfaces.pokedex.pokeAPI.modelos;

public class Types {
    private Type type;
    private int slot;

    public Type getType() {
        return type;
    }

    public int getSlot() {
        return slot;
    }
}